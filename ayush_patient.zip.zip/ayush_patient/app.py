from flask import Flask, render_template, request, redirect, session
import mysql.connector
import hashlib
from datetime import date

app = Flask(__name__)
app.secret_key = "sih2026secret"

db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="yourpassword",   # change to your MySQL password
    database="ayush_db"
)
cursor = db.cursor()


def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()


def dominant_dosha(vata, pitta, kapha):
    if vata >= pitta and vata >= kapha:
        return "Vata"
    elif pitta >= vata and pitta >= kapha:
        return "Pitta"
    else:
        return "Kapha"


def get_today_settings():
    today = date.today()
    cursor.execute("SELECT max_tokens, registration_closed FROM daily_settings WHERE visit_date=%s", (today,))
    row = cursor.fetchone()
    if not row:
        cursor.execute("INSERT INTO daily_settings (visit_date) VALUES (%s)", (today,))
        db.commit()
        return 50, False
    return row[0], bool(row[1])


def todays_count():
    today = date.today()
    cursor.execute("SELECT COUNT(*) FROM patients WHERE visit_date=%s", (today,))
    return cursor.fetchone()[0]


# ---------- HOME ----------
@app.route('/')
def home():
    return render_template('home.html')


# ---------- ADMIN LOGIN ----------
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        cursor.execute("SELECT password FROM admin WHERE username=%s", (username,))
        row = cursor.fetchone()
        if row and hash_password(password) == row[0]:
            session['admin'] = username
            return redirect('/view-patients')
        return render_template('login.html', error="Invalid username or password")
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.pop('admin', None)
    return redirect('/login')


# ---------- ADD PATIENT ----------
@app.route('/add-patient', methods=['GET', 'POST'])
def add_patient():
    today = date.today()
    max_tokens, closed = get_today_settings()
    count_today = todays_count()
    full = closed or count_today >= max_tokens

    if request.method == 'POST':
        if full:
            return render_template('add_patient.html', full=True)

        token_no = count_today + 1
        name = request.form['name']
        dob = request.form['dob'] or None
        age = request.form['age']
        gender = request.form['gender']
        contact = request.form['contact']
        address = request.form['address']
        symptoms = request.form['symptoms']
        referred_hospital = request.form['referred_hospital']

        bp_sys = request.form['bp_sys'] or None
        bp_dia = request.form['bp_dia'] or None
        pulse = request.form['pulse'] or None
        weight = request.form['weight'] or None
        temperature = request.form['temperature'] or None

        vata = int(request.form['vata'] or 5)
        pitta = int(request.form['pitta'] or 5)
        kapha = int(request.form['kapha'] or 5)
        dosha = dominant_dosha(vata, pitta, kapha)

        query = """INSERT INTO patients
            (token_no, visit_date, name, dob, age, gender, contact, address,
             symptoms, referred_hospital, bp_systolic, bp_diastolic, pulse,
             weight, temperature, vata_score, pitta_score, kapha_score, dominant_dosha)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
        cursor.execute(query, (token_no, today, name, dob, age, gender, contact, address,
                                symptoms, referred_hospital, bp_sys, bp_dia, pulse,
                                weight, temperature, vata, pitta, kapha, dosha))
        db.commit()

        return render_template('token_slip.html', token_no=token_no, name=name, visit_date=today)

    return render_template('add_patient.html', next_token=count_today + 1, full=full)


# ---------- VIEW PATIENTS (admin only, with search) ----------
@app.route('/view-patients')
def view_patients():
    if 'admin' not in session:
        return redirect('/login')

    search = request.args.get('search', '').strip()
    if search:
        query = "SELECT * FROM patients WHERE name LIKE %s OR token_no = %s ORDER BY visit_date DESC, token_no DESC"
        like_search = f"%{search}%"
        try:
            token_search = int(search)
        except ValueError:
            token_search = -1
        cursor.execute(query, (like_search, token_search))
    else:
        cursor.execute("SELECT * FROM patients ORDER BY visit_date DESC, token_no DESC")

    patients = cursor.fetchall()
    return render_template('view_patients.html', patients=patients, search=search)


# ---------- PATIENT DETAIL ----------
@app.route('/patient/<int:patient_id>')
def patient_detail(patient_id):
    if 'admin' not in session:
        return redirect('/login')

    cursor.execute("SELECT * FROM patients WHERE id=%s", (patient_id,))
    patient = cursor.fetchone()

    cursor.execute("SELECT * FROM case_history WHERE patient_id=%s", (patient_id,))
    history = cursor.fetchall()

    cursor.execute("SELECT * FROM prescriptions WHERE patient_id=%s", (patient_id,))
    prescriptions = cursor.fetchall()

    return render_template('patient_detail.html', patient=patient, history=history, prescriptions=prescriptions)


# ---------- ADD CASE HISTORY ----------
@app.route('/add-case-history/<int:patient_id>', methods=['GET', 'POST'])
def add_case_history(patient_id):
    if 'admin' not in session:
        return redirect('/login')

    if request.method == 'POST':
        chief_complaint = request.form['chief_complaint']
        past_history = request.form['past_history']
        family_history = request.form['family_history']
        visit_date = request.form['date']

        query = """INSERT INTO case_history
            (patient_id, chief_complaint, past_history, family_history, date)
            VALUES (%s,%s,%s,%s,%s)"""
        cursor.execute(query, (patient_id, chief_complaint, past_history, family_history, visit_date))
        db.commit()
        return redirect(f'/patient/{patient_id}')

    return render_template('add_case_history.html', patient_id=patient_id)


# ---------- ADD PRESCRIPTION ----------
@app.route('/add-prescription/<int:patient_id>', methods=['GET', 'POST'])
def add_prescription(patient_id):
    if 'admin' not in session:
        return redirect('/login')

    if request.method == 'POST':
        medicine = request.form['medicine']
        dosage = request.form['dosage']
        duration = request.form['duration']
        prescribed_by = request.form['prescribed_by']
        visit_date = request.form['date']

        query = """INSERT INTO prescriptions
            (patient_id, medicine, dosage, duration, prescribed_by, date)
            VALUES (%s,%s,%s,%s,%s,%s)"""
        cursor.execute(query, (patient_id, medicine, dosage, duration, prescribed_by, visit_date))
        db.commit()
        return redirect(f'/patient/{patient_id}')

    return render_template('add_prescription.html', patient_id=patient_id)


# ---------- REGISTRATION SETTINGS (admin only) ----------
@app.route('/settings', methods=['GET', 'POST'])
def settings():
    if 'admin' not in session:
        return redirect('/login')

    today = date.today()
    if request.method == 'POST':
        new_max = request.form.get('max_tokens')
        if new_max:
            cursor.execute("UPDATE daily_settings SET max_tokens=%s WHERE visit_date=%s", (new_max, today))
            db.commit()

    max_tokens, closed = get_today_settings()
    count_today = todays_count()
    return render_template('settings.html', max_tokens=max_tokens, closed=closed, count_today=count_today)


@app.route('/toggle-registration', methods=['POST'])
def toggle_registration():
    if 'admin' not in session:
        return redirect('/login')

    today = date.today()
    cursor.execute("UPDATE daily_settings SET registration_closed = NOT registration_closed WHERE visit_date=%s", (today,))
    db.commit()
    return redirect('/settings')


if __name__ == '__main__':
    app.run(debug=True)