import mysql.connector
import hashlib


def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()


db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="yourpassword",   # change to your MySQL password
    database="ayush_db"
)
cursor = db.cursor()

username = "admin"
password = "admin123"   # change this before your demo

cursor.execute(
    "INSERT INTO admin (username, password) VALUES (%s, %s)",
    (username, hash_password(password))
)
db.commit()
print("Admin account created.")